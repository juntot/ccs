require('./bootstrap');
require('./scanner');
require('./report');
require('./user');




// DTable.buttons().container().appendTo( '#report-table .col-md-6:eq(0)' );