<!-- plugins:js -->
  <script src="<?php echo e(URL::to('/public/template/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <script src="<?php echo e(URL::to('/public/template/vendors/chart.js/Chart.min.js')); ?>"></script>
  <!-- <script src="<?php echo e(URL::to('/public/template/vendors/datatables.net/jquery.dataTables.js')); ?>"></script>
  <script src="<?php echo e(URL::to('/public/template/vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
  <script src="<?php echo e(URL::to('/public/template/js/dataTables.select.min.js')); ?>"></script> -->

  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="<?php echo e(URL::to('/public/template/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(URL::to('/public/template/js/hoverable-collapse.js')); ?>"></script>
  <script src="<?php echo e(URL::to('/public/template/js/template.js')); ?>"></script>
  <script src="<?php echo e(URL::to('/public/template/js/settings.js')); ?>"></script>
  
  <!-- endinject -->
  <!-- Custom js for this page-->
  <!-- <script src="<?php echo e(URL::to('/public/template/js/dashboard.js')); ?>"></script> -->
  <script src="<?php echo e(URL::to('/public/template/js/Chart.roundedBarCharts.js')); ?>"></script>
  <!-- End custom js for this page-->
<?php echo $__env->yieldContent('script'); ?>
<?php /**PATH /Users/shitmiming/web/saas/resources/views/layout/footer_asset.blade.php ENDPATH**/ ?>