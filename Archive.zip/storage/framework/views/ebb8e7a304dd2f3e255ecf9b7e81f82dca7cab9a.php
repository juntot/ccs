<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>

  html, body{
    /* height: 100% !important; */
    padding: 0 !important;
    margin: 0 !important;
  }
  body{
    /* background: linear-gradient(to right, rgba(39, 70, 133, 0.8) 0%, rgba(61, 179, 197, 0.8) 100%) !important; */
/* background: red !important; */
  background: linear-gradient(to right, rgba(39, 70, 133, 0.8) 0%, rgba(61, 179, 197, 0.8) 100%), url('https://bootstrapmade.com/demo/templates/SoftLand/assets/img/hero-bg.jpg');

  }
  .align-items-center{
    height: 100% !important;
  }
  h6{
    color: #4B49AC;
  }
  li{
    padding-bottom: 12px;
  }

  .detail-container{
    position: absolute;
    width: 100%;
    top: 10%;
  }
  .svg{
    position: absolute;
    left: 0;
    width: 100%;
    bottom: 0;
  }
  .svg:before {
    content: "";
    background: #F5F7FF;
    width: 100%;
    height: 50%;
    top: 50%;
    position: absolute;
  }
  .row{
    margin: 0 !important;
  }

  .strech-card{
    padding: 0 !important;
  }
</style>

<body class="content-wrapperx">
  <div class="svg">
        <svg width="100%" height="355px" viewBox="0 0 1920 355" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"> 
        <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"> 
        <g id="Apple-TV" transform="translate(0.000000, -402.000000)" fill="#F5F7FF"> 
        <path d="M0,439.134243 C175.04074,464.89273 327.944386,477.771974 458.710937,477.771974 C654.860765,477.771974 870.645295,442.632362 1205.9828,410.192501 C1429.54114,388.565926 1667.54687,411.092417 1920,477.771974 L1920,757 L1017.15166,757 L0,757 L0,439.134243 Z" id="Path"></path> 
        </g> 
        </g> 
      </svg>
  </div>
<?php if($result): ?>
    <div class="detail-container">
          <div class="row justify-content-center align-items-center">
            <div class="col-md-4 col-sm-8 col-xs-10 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <ul class="bullet-line-list">
                    <li>
                      <h6>Product ID</h6>
                      <p><?php echo e($result->prodId); ?> </p>
                    </li>
                    <li>
                      <h6>Product Name</h6>
                      <p><?php echo e($result->prodName); ?> </p>
                    </li>
                    <li>
                      <h6>Category</h6>
                      <p><?php echo e($result->category); ?> </p>
                    </li>
                    <li>
                      <h6>Quantity</h6>
                      <p><?php echo e($result->qty); ?> </p>
                    </li>
                    <li>
                      <h6>Base Price</h6>
                      <p><?php echo e($result->basePrice); ?> </p>
                    </li>
                    <li>
                      <h6>Selling Price</h6>
                      <p><?php echo e($result->sellingPrice); ?> </p>
                    </li>
                    <li>
                      <h6>Reorder Point</h6>
                      <p><?php echo e($result->reorderPoint); ?> </p>
                    </li>
                    <li>
                      <h6>Added By</h6>
                      <p><?php echo e($result->addedby_); ?> </p>
                    </li>
                    <li>
                      <h6>Date Added</h6>
                      <p class="text-muted">
                        <i class="ti-time"></i>
                        7 months ago.
                      </p>
                    </li>
                    <li>
                      <h6>Updated By</h6>
                      <p><?php echo e($result->updatedby_); ?> </p>
                    </li>
                    <li>
                      <h6>Updated At</h6>
                      <p class="text-muted">
                        <i class="ti-time"></i>
                        7 months ago.
                      </p>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
    </div>
  <?php endif; ?>
</body>
</html><?php /**PATH /Users/shitmiming/web/saas/resources/views/productdetail.blade.php ENDPATH**/ ?>