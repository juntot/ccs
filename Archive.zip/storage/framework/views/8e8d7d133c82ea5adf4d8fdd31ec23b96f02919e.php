<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('main'); ?>
    <!-- Footer -->
    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End of Footer -->
        
</body>

</html><?php /**PATH /Users/shitmiming/web/qrscan/resources/views/layout/master.blade.php ENDPATH**/ ?>