<?php $__env->startSection('style'); ?>
<style>
 .ml-3{
   margin-left: 1em;
 }
 .progress.progress-md{
   height: 7px;
 }
 .tab-content{
   padding: 2rem;
 }
 
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="row">
  <div class="col-md-12 grid-margin">
    <div class="card">
      <div class="card-body">
              <p class="card-title">User Profile</p>
              <div class="row mb-3">
                <div class="col-lg-12">
                  <div class="d-sm-flex flex-row flex-wrap text-center text-sm-left align-items-center">
                    <img src="<?php echo e(Session::get('auth.avatar') ? Session::get('auth.avatar') : URL::to('/public/template/images/faces/face1.jpg ')); ?>" class="img-lg rounded-circle mb-2" alt="profile image">
                    <div class="ml-3">
                      <h4>Mark Leet</h4>
                      <p class="mb-0 text-primary">Administrator</p>
                    </div>
                  </div>  
								</div>
              </div>
              <div class="progress progress-md mb-4">
                <div class="progress-bar bg-info w-100" role="progressbar" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
              <!-- Nav tabs -->
              <ul class="nav nav-tabs">
                <li class="nav-item">
                  <a class="nav-link active" data-toggle="tab" href="#home">User Information</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#menu1">Security</a>
                </li>
              </ul>

              <!-- Tab panes -->
              <form method="post" action="save-userprofile">
                  <?php echo e(csrf_field()); ?>

                  <div class="tab-content">
                    <div class="tab-pane active" id="home">
                          <div class="row">
                            <div class="col-lg-12">
                                <div class="form-group has-danger">
                                    <label>Full Name</label>
                                    <div class="input-group">
                                      <div class="input-group-prepend bg-transparent">
                                        <span class="input-group-text bg-transparent border-right-0">
                                          <i class="ti-user text-primary"></i>
                                        </span>
                                      </div>
                                      <input type="text" value="<?php echo e(Session::get('auth.fullname')); ?>" name="fullName" class="form-control form-control-lg border-left-0" placeholder="Full Name">
                                    </div>
                                    <small class="text-danger">error</small>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group has-danger">
                                    <label>State</label>
                                    <div class="input-group">
                                      <div class="input-group-prepend bg-transparent">
                                        <span class="input-group-text bg-transparent border-right-0">
                                          <i class="ti-flag-alt text-primary"></i>
                                        </span>
                                      </div>
                                      <input type="text" value="<?php echo e(Session::get('auth.state')); ?>" name="state" class="form-control form-control-lg border-left-0" placeholder="State">
                                    </div>
                                    <small class="text-danger">error</small>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group has-danger">
                                    <label>Suburb</label>
                                    <div class="input-group">
                                      <div class="input-group-prepend bg-transparent">
                                        <span class="input-group-text bg-transparent border-right-0">
                                          <i class="ti-direction text-primary"></i> 
                                        </span>
                                      </div>
                                      <input type="text" value="<?php echo e(Session::get('auth.suburb')); ?>" name="suburb" class="form-control form-control-lg border-left-0" placeholder="Suburb">
                                    </div>
                                    <small class="text-danger">error</small>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group has-danger">
                                    <label>Mobile Number</label>
                                    <div class="input-group">
                                      <div class="input-group-prepend bg-transparent">
                                        <span class="input-group-text bg-transparent border-right-0">
                                          <i class="ti-mobile text-primary"></i>
                                        </span>
                                      </div>
                                      <input type="text" value="<?php echo e(Session::get('auth.mobile')); ?>" name="mobile" class="form-control form-control-lg border-left-0" placeholder="Mobile">
                                    </div>
                                    <small class="text-danger">error</small>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group has-danger">
                                    <label>Email</label>
                                    <div class="input-group">
                                      <div class="input-group-prepend bg-transparent">
                                        <span class="input-group-text bg-transparent border-right-0">
                                        <i class="ti-email text-primary"></i>
                                        </span>
                                      </div>
                                      <input type="text" value="<?php echo e(Session::get('auth.email')); ?>" name="email" class="form-control form-control-lg border-left-0" placeholder="Email">
                                    </div>
                                    <small class="text-danger">error</small>
                                </div>
                            </div>
                          </div>
                          <!-- <button class="btn btn-primary user-basic-info">Save</button> -->
                    </div>
                    <div class="tab-pane fade" id="menu1">
                          <div class="row">
                              <div class="col-lg-12">
                                <div class="form-group has-danger">
                                    <label>Old Password</label>
                                    <div class="input-group">
                                      <div class="input-group-prepend bg-transparent">
                                        <span class="input-group-text bg-transparent border-right-0">
                                          <i class="ti-lock text-primary"></i>
                                        </span>
                                      </div>
                                      <input type="text" value="" name="old_pass" class="form-control form-control-lg border-left-0" placeholder="Old Password">
                                    </div>
                                    <small class="text-danger">error</small>
                                </div>
                              </div>
                              <div class="col-lg-12">
                                <div class="form-group has-danger">
                                    <label>New Password</label>
                                    <div class="input-group">
                                      <div class="input-group-prepend bg-transparent">
                                        <span class="input-group-text bg-transparent border-right-0">
                                          <i class="ti-lock text-primary"></i>
                                        </span>
                                      </div>
                                      <input type="text" value="" name="password" class="form-control form-control-lg border-left-0" placeholder="New Password">
                                    </div>
                                    <small class="text-danger">error</small>
                                </div>
                              </div>
                              <div class="col-lg-12">
                                <div class="form-group has-danger">
                                    <label>Confirm New Password</label>
                                    <div class="input-group">
                                      <div class="input-group-prepend bg-transparent">
                                        <span class="input-group-text bg-transparent border-right-0">
                                          <i class="ti-lock text-primary"></i>
                                        </span>
                                      </div>
                                      <input type="text" value="" name="new_password" class="form-control form-control-lg border-left-0" placeholder="Confirm Password">
                                    </div>
                                    <small class="text-danger">error</small>
                                </div>
                              </div>
                          </div>
                    </div>
                    <button class="btn btn-primary user-security">Save</button>
                  </div>
              </form>
              <!-- end Nav tabs -->
        </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(URL::to('/public/template/js/form-validation.js')); ?>"></script>
<script src="<?php echo e(URL::to('/public/template/vendors/datatables.net/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(URL::to('/public/template/vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
<!-- <script src="<?php echo e(URL::to('/public/template/js/data-table.js')); ?>"></script> -->
<script>
  $(function() {
    $('#order-listing').DataTable({
      "aLengthMenu": [
        [5, 10, 15, -1],
        [5, 10, 15, "All"]
      ],
      "iDisplayLength": 10,
      "language": {
        search: ""
      },
      bInfo: true,
      bLengthChange: false,
    });
    $('#order-listing').each(function() {
      var datatable = $(this);
      // SEARCH - Add the placeholder for Search and Turn this into in-line form control
      var search_input = datatable.closest('.dataTables_wrapper').find('div[id$=_filter] input');
      search_input.attr('placeholder', 'Search');
      // search_input.removeClass('form-control-sm');
      // LENGTH - Inline-Form control
      // var length_sel = datatable.closest('.dataTables_wrapper').find('div[id$=_length] select');
      // length_sel.removeClass('form-control-sm');
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shitmiming/web/saas/resources/views/userprofile.blade.php ENDPATH**/ ?>