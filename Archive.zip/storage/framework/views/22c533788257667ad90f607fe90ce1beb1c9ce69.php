<!DOCTYPE html>
<html lang="en">
  <head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"> -->
  <title>Skydash Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo e(URL::to('/public/template/vendors/feather/feather.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(URL::to('/public/template/vendors/ti-icons/css/themify-icons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(URL::to('/public/template/vendors/css/vendor.bundle.base.css')); ?>">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"> -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo e(URL::to('/public/template/css/vertical-layout-light/style.css')); ?>">
  <!-- endinject -->
  <!-- <link rel="shortcut icon" href="images/favicon.png"> -->
  <link rel="shortcut icon" href="<?php echo e(URL::to('/public/template/images/logo-mini.png')); ?>" />
  <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/app.css')); ?> ">
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-stretch auth auth-img-bg">
        <div class="row flex-grow">
          <div class="col-lg-6 d-flex align-items-center justify-content-center">
      <!-- toast -->
          <div class="toast" data-delay="3000">
              <div class="toast-header">
                <strong class="mr-auto text-primary">Message</strong>
                <button type="button" class="ml-2 mb-1 close" data-dismiss="toast">&times;</button>
              </div>
              <div class="toast-body">
                <?php echo e(Session::get('success')); ?>

              </div>
            </div>
            <!-- endtoast -->
            <div class="auth-form-transparent text-left p-3">
              <div class="brand-logo">
                <img src="<?php echo e(URL::to('/public/template/images/logo.png')); ?>" alt="logo">
              </div>
              <h4>Welcome back!</h4>
              <h6 class="font-weight-light">Happy to see you again!</h6>
              <form class="pt-3" method="POST" action="forgetpass">
                <div class="form-group">
                  <label for="email">Email</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="ti-lock text-primary"></i>
                      </span>
                    </div>
                    <input type="email" name="email" class="form-control form-control-lg border-left-0" id="email" placeholder="Email">                        
                  </div>
                  <?php if($errors->any()): ?>
                  <small class="text-center text-danger block"><?php echo e($errors->first('message')); ?></small>
                  <?php endif; ?>
                </div>
                
                <div class="my-3">
                  <?php echo e(csrf_field()); ?>

                  <!-- <a class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" href="../../index.html">LOGIN</a> -->
                  <input type="submit" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" value="Submit">
                </div>
                <div class="text-center mt-4 font-weight-light">
                  Already have an account? <a href="<?php echo e(route('login')); ?>" class="text-primary">Login</a>
                </div>
                <div class="text-center mt-1 font-weight-light">
                    
                </div>
                
              </form>
            </div>
            
          </div>
          <div class="col-lg-6 login-half-bg d-flex flex-row hide-on-mobile-background">
            <p class="text-white font-weight-medium text-center flex-grow align-self-end">Copyright © 2021  All rights reserved.</p>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="<?php echo e(URL::to('/public/template/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="<?php echo e(URL::to('/public/template/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(URL::to('/public/template/js/hoverable-collapse.js')); ?>"></script>
  <script src="<?php echo e(URL::to('/public/template/js/template.js')); ?>"></script>
  <script src="<?php echo e(URL::to('/public/template/js/settings.js')); ?>"></script>
  <script src="<?php echo e(URL::to('/public/template/js/todolist.js')); ?>"></script>
  <!-- endinject -->
  <script>
    var response  = <?php echo json_encode(Session::get('success')); ?>;
    $(document).ready(function(){
      if(response)
      $('.toast').toast('show');
    });
  </script>


</body></html><?php /**PATH /Users/shitmiming/web/saas/resources/views/forgetpass.blade.php ENDPATH**/ ?>