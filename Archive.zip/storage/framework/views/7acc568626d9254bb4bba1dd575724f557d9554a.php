<?php $__env->startSection('style'); ?>
<style>
  .toast.show{
    top: 12% !important;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<div class="row">
  <div class="col-md-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#inventoryModal">
            Add New
        </button>
        <p class="card-title mt-5">Products</p>
        <div class="row">
          <div class="col-12">
            <div class="table-responsive">
            <table id="order-listing" class="display expandable-table" role="grid" aria-describedby="order-listing_info" style="width: 100%;"></table>
                      <!-- <thead>
                        <tr role="row">
                          <th class="sorting" tabindex="0" aria-controls="order-listing" rowspan="1" colspan="1" aria-label="Order #: activate to sort column ascending" style="width: 50.0391px;">Order #</th>
                          <th class="sorting" tabindex="0" aria-controls="order-listing" rowspan="1" colspan="1" aria-label="Purchased On: activate to sort column ascending" style="width: 90.75px;">Purchased On</th>
                          <th class="sorting" tabindex="0" aria-controls="order-listing" rowspan="1" colspan="1" aria-label="Customer: activate to sort column ascending" style="width: 62.9375px;">Customer</th>
                          <th class="sorting" tabindex="0" aria-controls="order-listing" rowspan="1" colspan="1" aria-label="Ship to: activate to sort column ascending" style="width: 52.1484px;">Ship to</th>
                          <th class="sorting_asc" tabindex="0" aria-controls="order-listing" rowspan="1" colspan="1" aria-label="Base Price: activate to sort column descending" style="width: 67.6094px;" aria-sort="ascending">Base Price</th>
                          <th class="sorting" tabindex="0" aria-controls="order-listing" rowspan="1" colspan="1" aria-label="Purchased Price: activate to sort column ascending" style="width: 103.672px;">Purchased Price</th>
                          <th class="sorting" tabindex="0" aria-controls="order-listing" rowspan="1" colspan="1" aria-label="Status: activate to sort column ascending" style="width: 60.8438px;">Status</th>
                          <th class="sorting" tabindex="0" aria-controls="order-listing" rowspan="1" colspan="1" aria-label="Actions: activate to sort column ascending" style="width: 58.3594px;">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                      <tr class="oddx">
                            <td class="">10</td>
                            <td class="">2003/12/26</td>
                            <td class="">Tom</td>
                            <td>Germany</td>
                            <td class="sorting_1">$1100</td>
                            <td>$2300</td>
                            <td>
                              <label class="badge badge-danger">Pending</label>
                            </td>
                            <td>
                              <button class="btn btn-outline-primary">View</button>
                            </td>
                        </tr>
                        <tr class="evenx">
                            <td class="">1</td>
                            <td class="">2012/08/03</td>
                            <td class="">Edinburgh</td>
                            <td>New York</td>
                            <td class="sorting_1">$1500</td>
                            <td>$3200</td>
                            <td>
                              <label class="badge badge-info">On hold</label>
                            </td>
                            <td>
                              <button class="btn btn-outline-primary">View</button>
                            </td>
                        </tr>
                        <tr class="oddx">
                            <td class="">7</td>
                            <td class="">2011/03/11</td>
                            <td class="">Cris</td>
                            <td>Tokyo</td>
                            <td class="sorting_1">$2100</td>
                            <td>$6300</td>
                            <td>
                              <label class="badge badge-success">Closed</label>
                            </td>
                            <td>
                              <button class="btn btn-outline-primary">View</button>
                            </td>
                        </tr>
                        <tr class="evenx">
                            <td class="">9</td>
                            <td class="">2016/11/12</td>
                            <td class="">John</td>
                            <td>Tokyo</td>
                            <td class="sorting_1">$2100</td>
                            <td>$6300</td>
                            <td>
                              <label class="badge badge-success">Closed</label>
                            </td>
                            <td>
                              <button class="btn btn-outline-primary">View</button>
                            </td>
                        </tr>
                        <tr class="oddx">
                            <td class="">6</td>
                            <td class="">2000/10/30</td>
                            <td class="">Sam</td>
                            <td>Tokyo</td>
                            <td class="sorting_1">$2100</td>
                            <td>$6300</td>
                            <td>
                              <label class="badge badge-info">On-hold</label>
                            </td>
                            <td>
                              <button class="btn btn-outline-primary">View</button>
                            </td>
                        </tr>
                        <tr class="evenx">
                            <td class="">3</td>
                            <td class="">2010/11/21</td>
                            <td class="">Sam</td>
                            <td>Tokyo</td>
                            <td class="sorting_1">$2100</td>
                            <td>$6300</td>
                            <td>
                              <label class="badge badge-success">Closed</label>
                            </td>
                            <td>
                              <button class="btn btn-outline-primary">View</button>
                            </td>
                        </tr>
                        <tr class="oddx">
                            <td class="">4</td>
                            <td class="">2016/01/12</td>
                            <td class="">Sam</td>
                            <td>Tokyo</td>
                            <td class="sorting_1">$2100</td>
                            <td>$6300</td>
                            <td>
                              <label class="badge badge-success">Closed</label>
                            </td>
                            <td>
                              <button class="btn btn-outline-primary">View</button>
                            </td>
                        </tr>
                        <tr class="evenx">
                            <td class="">5</td>
                            <td class="">2017/12/28</td>
                            <td class="">Sam</td>
                            <td>Tokyo</td>
                            <td class="sorting_1">$2100</td>
                            <td>$6300</td>
                            <td>
                              <label class="badge badge-success">Closed</label>
                            </td>
                            <td>
                              <button class="btn btn-outline-primary">View</button>
                            </td>
                        </tr>
                        <tr class="oddx">
                            <td class="">2</td>
                            <td class="">2015/04/01</td>
                            <td class="">Doe</td>
                            <td>Brazil</td>
                            <td class="sorting_1">$4500</td>
                            <td>$7500</td>
                            <td>
                              <label class="badge badge-danger">Pending</label>
                            </td>
                            <td>
                              <button class="btn btn-outline-primary">View</button>
                            </td>
                        </tr>
                        <tr class="evenx">
                            <td class="">8</td>
                            <td class="">2015/06/25</td>
                            <td class="">Tim</td>
                            <td>Italy</td>
                            <td class="sorting_1">$6300</td>
                            <td>$2100</td>
                            <td>
                              <label class="badge badge-info">On-hold</label>
                            </td>
                            <td>
                              <button class="btn btn-outline-primary">View</button>
                            </td>
                        </tr></tbody>
                    </table> -->
            </div>
          </div>
        </div>
        </div>
      </div>
    </div>
  </div>

<!-- The Modal -->
<div class="modal fade" id="inventoryModal">
  <div class="modal-dialog modal-lgx">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add New Product</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-bodyx">
      <form class="cmxform" id="inventoryForm" method="get" action="/">
      <div class="card">
          <div class="card-body">
                <div class="svg-qrcode text-center"></div>
                <fieldset class="inventory-form">
                  <div class="form-group">
                    <label for="prodName">Product Name</label>
                    <input id="prodName" class="form-control" name="prodName" type="text">
                  </div>
                  <!-- <div class="form-group">
                    <label for="category">Category</label>
                    <input id="category" class="form-control" name="category" type="text">
                  </div> -->
                  <div class="form-group">
                    <label for="exampleFormControlSelect3">Category</label>
                    <select class="form-control form-control" id="exampleFormControlSelect" name="category">
                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->categoryId); ?>"><?php echo e($category->categoryName); ?></option>  
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="qty">Qty</label>
                    <input id="qty" class="form-control" name="qty" type="text">
                  </div>
                  <div class="form-group">
                    <label for="basePrice">Base Price</label>
                    <input id="basePrice" class="form-control" name="basePrice" type="text">
                  </div>
                  <div class="form-group">
                    <label for="sellingPrice">Selling Price</label>
                    <input id="sellingPrice" class="form-control" name="sellingPrice" type="text">
                  </div>
                  <div class="form-group">
                    <label for="reorderPoint">Reorder Point</label>
                    <input id="reorderPoint" class="form-control" name="reorderPoint" type="text">
                  </div>
                </fieldset>
              
            </div>
          </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary inventory-form" id="btnSubmit">Submit</button>
        <button type="submit" class="btn btn-primary inventory-form" style="display:none" id="btnUpdate">Update</button>
      </div>
    </form>
    </div>
  </div>
</div>
<!-- toast -->
<div class="toast" data-delay="3000">
  <div class="toast-header">
    <strong class="mr-auto text-primary">Message</strong>
    <button type="button" class="ml-2 mb-1 close" data-dismiss="toast">&times;</button>
  </div>
  <div class="toast-body">
      TOAS
  </div>
</div>
<!-- endtoast -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- Page level plugins -->


<script src="<?php echo e(URL::to('/public/template/vendors/datatables.net/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(URL::to('/public/template/vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
<!-- <script src="<?php echo e(URL::to('/public/template/js/data-table.js')); ?>"></script> -->

<script src="<?php echo e(URL::to('/public/template/vendors/jquery-validation/jquery.validate.min.js')); ?>"></script>
<!-- <script src="<?php echo e(URL::to('/public/template/vendors/bootstrap-maxlength/bootstrap-maxlength.min.js')); ?>"></script> -->
<!-- <script src="<?php echo e(URL::to('/public/template/js/form-validation.js')); ?>"></script> -->
<script src="<?php echo e(URL::to('/public/index.js')); ?>"></script>
<script>
  
  var items = <?php echo json_encode($result); ?>

  $(function() {
    $("#inventoryForm").validate({
    debug: false,
    submitHandler: function(form) {
      // console.log($(form).ajaxSubmit());
      // console.log(form.submit());
      // console.log(form);
      
    },
    rules: {
      prodName: "required",
      category: "required",
      qty: {
        required: true,
        digits: true,
      },
      basePrice: {
        required: true,
        number: true,
      },
      sellingPrice: {
        required: true,
        number: true,
      },
      reorderPoint: {
        required: true,
        digits: true,
      },
    },
    messages: {
      prodName: "Please enter your firstname",
      category: "Please enter your lastname",
      qty: {
        required: "Please enter your lastname",
        digits: "Only digits is allowed"
      },
      basePrice: {
        required: "Please enter your lastname",
        number: "Only digits is allowed"
      },
      sellingPrice: {
        required: "Please enter your lastname",
        number: "Only digits is allowed"
      },
      reorderPoint: {
        required: "Please enter your lastname",
        digits: "Only digits is allowed"
      },
    },
    errorPlacement: function(label, element) {
      label.addClass('mt-2 text-danger');
      label.insertAfter(element);
    },
    highlight: function(element, errorClass) {
      $(element).parent().addClass('has-danger')
      $(element).addClass('form-control-danger')
    }
  });

  $('#btnSubmit').click(function(e) {
        e.preventDefault();
        var isFormValid = $("#inventoryForm").valid();
        if(!isFormValid)
        return;
        var formData = $("#inventoryForm").serialize().split('&');
        var params = {};
        formData.forEach(element => {
            params[element.slice(0, element.indexOf('='))] = (element.slice(element.indexOf('=')+1)).replace(/%20/g, " ");
        });

        request('product', 'POST', JSON.stringify(params), function(status, data){
          if(status == 200)
          {
            

            var response = data.split("&");
            $('.inventory-form').hide();
            $('.svg-qrcode').show();
            $('.svg-qrcode').html(response[3] || '');
            
            
            params['prodId'] = response[0] || '';
            params['created_at'] = response[1] || '';
            params['updated_at'] = response[2] || '';
            params['qr'] = response[3] || '';
            params['categoryName'] = $("#exampleFormControlSelect option:selected" ).text();
            
            // return;
            table.row.add(params).draw();
            
          }else{
            $('.text-danger').text(data);
          }
        });
    });

    $('#btnUpdate').click(function(e) {
        e.preventDefault();
        var isFormValid = $("#inventoryForm").valid();
        if(!isFormValid)
        return;
        // var categoryName = $( "#category option:selected" ).text();
        var formData = $("#inventoryForm").serialize().split('&');
        var params = {
          prodId: $('#btnUpdate').attr('data-id'),
          categoryName: $("#exampleFormControlSelect option:selected" ).text()
        };
        formData.forEach(element => {
            params[element.slice(0, element.indexOf('='))] = (element.slice(element.indexOf('=')+1)).replace(/%20/g, " ");
        });
        
        
        request('product', 'PATCH', JSON.stringify(params), async function(status, data){
          if(status == 200)
          {
            console.log(data, trIndex);
            data['created_at'] = selectedRow.created_at;
            table.row( trIndex ).data( data ).draw();

            $("#inventoryModal").modal('hide');
            $('.toast-body').html('Successfully Updated');
            $('.toast').toast('show');
            
          }else{
            $('.text-danger').text(data);
          }
        });
    });
    var selectedRow = '';
    var trIndex = '';
    var table = $('#order-listing').DataTable({
      data: items,
      order: [[ 0, "desc" ]],
      columns: [
        { data: 'prodId', title:'Product ID',  className: "table-prodId", render: function(data){
            return '<a href="#">'+data+'</a>';
        }},
        
        { data: 'prodName', title:'Product Name' },
        { data: 'categoryName', title: 'Category'},
        { data: 'qty', title: 'Qty' },
        { data: 'basePrice', title: 'Base Price' },
        { data: 'sellingPrice', title: 'Selling Price' },
        { data: 'reorderPoint', title: 'Reorder Point' },
        { data: 'created_at', title: 'Date Created' },
        { data: 'updated_at', title: 'Date Updated' },
        { data: 'qr', title: 'QR',  render: function(data){
          return '<label class="badge badge-info btn-view-qr"><a href="#" class="text-white">View QR</a></label>';
        }},
        {title: 'Action', render: function(data){
          return '<label class="badge badge-danger btn-delete-row"><a href="#" class="text-white">remove</a></label>';
        }}
      ],
      "aLengthMenu": [
        [5, 10, 15, -1],
        [5, 10, 15, "All"]
      ],
      "iDisplayLength": 10,
      "language": {
        search: ""
      },
      bInfo: true,
      bLengthChange: false,
    });

    // get row data
    $('#order-listing tbody').on( 'click', 'tr td.table-prodId', function () {
        $('#btnSubmit').hide();
        $('#btnUpdate').show();
        var d = table.row( this ).data();
        selectedRow = d;
        // trIndex = $(this).closest("tr").index();
        trIndex = $(this);

        $('.modal-title').html('Update Product');
        $('#prodName').val(d.prodName);
        $('#category').val(d.category);
        $('#qty').val(d.qty);
        $('#basePrice').val(d.basePrice);
        $('#sellingPrice').val(d.sellingPrice);
        $('#reorderPoint').val(d.reorderPoint);

        $('#btnUpdate').attr("data-id", d.prodId);
        $("#inventoryModal").modal('show');
    });

    // get qr code
    $('#order-listing tbody').on( 'click', 'tr label.btn-view-qr', function () {
        $('.inventory-form').hide();
        var d = table.row( $(this).parent() ).data();
        
        $('.modal-title').html('');
        $('.svg-qrcode').show();
        $('.svg-qrcode').html(d.qr);
        $("#inventoryModal").modal('show');
    });

    // Delete row
    $('#order-listing tbody').on( 'click', 'tr label.btn-delete-row', function () {
      table.row( $(this).parents('tr') ).remove().draw();
    });

    $('#order-listing').each(function() {
      var datatable = $(this);
      var search_input = datatable.closest('.dataTables_wrapper').find('div[id$=_filter] input');
      search_input.attr('placeholder', 'Search');
    });
  });

  $("#inventoryModal").on('hidden.bs.modal', function(){
      $('.modal-title').html('Add New Product');
      $('#btnSubmit').show();
      $('.inventory-form').show();
      $('#btnUpdate').hide();
      $('.svg-qrcode').hide ();
      $('#inventoryForm')[0].reset();
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shitmiming/web/saas/resources/views/product.blade.php ENDPATH**/ ?>