<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
  <title>SaaS Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo e(URL::to('/public/template/vendors/feather/feather.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(URL::to('/public/template/vendors/ti-icons/css/themify-icons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(URL::to('/public/template/vendors/css/vendor.bundle.base.css')); ?>">
  <!-- endinject -->
  <!-- fa -->
  <link rel="stylesheet" href="<?php echo e(URL::to('/public/template/vendors/mdi/css/materialdesignicons.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(URL::to('/public/template/vendors/font-awesome/css/font-awesome.min.css')); ?>">
  <!-- endFA -->
  <!-- datatable -->
  <link rel="stylesheet" href="<?php echo e(URL::to('/public/template/vendors/datatables.net-bs4/dataTables.bootstrap4.css')); ?>">
  <!-- endDatatable -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="<?php echo e(URL::to('/public/template/vendors/datatables.net-bs4/dataTables.bootstrap4.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(URL::to('/public/template/vendors/ti-icons/css/themify-icons.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/public/template/js/select.dataTables.min.css')); ?>">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo e(URL::to('/public/template/css/vertical-layout-light/style.css')); ?>">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo e(URL::to('/public/template/images/logo-mini.png')); ?>" />
  <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/app.css')); ?> ">
  <?php echo $__env->yieldContent('style'); ?>
</head><?php /**PATH /Users/shitmiming/web/saas/resources/views/layout/head.blade.php ENDPATH**/ ?>