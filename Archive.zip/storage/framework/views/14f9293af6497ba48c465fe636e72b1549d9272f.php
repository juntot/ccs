<?php $__env->startSection('style'); ?>
<style>
  .toast.show{
    top: 12% !important;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<div class="row">
  <div class="col-md-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <!-- <button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#modalProdCategory">
            Add New
        </button> -->
        <p class="card-title mt-5">Product Category</p>
        <div class="row">
          <div class="col-12">
            
                  <div class="card">
                    <div class="card-body">
                    <div class="add-items d-flex mb-0 mt-2">
                        <input type="text" class="form-control todo-list-input" placeholder="Add new category here..">
                        <button class="add btn btn-icon text-primary todo-list-add-btn bg-transparent"><i class="icon-circle-plus"></i></button>
                      </div>
                      <div class="list-wrapper pt-2">
                        <ul class="d-flex flex-column-reverse todo-list todo-list-custom">
                          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li>
                            <div class="form-check form-check-flat">
                              <a href="#"><label class="form-check-label product-category">
<?php echo e($category->categoryName); ?>

</label></a>
                            </div>
                            <i class="remove ti-close" data-id="<?php echo e($category->categoryId); ?>"></i>
                          </li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <!-- <li>
                            <div class="form-check form-check-flat">
                              <label class="form-check-label">
                                Meeting with Urban Team
                              <i class="input-helper"></i></label>
                            </div>
                            <i class="remove ti-close"></i>
                          </li> -->
                          <!-- <li class="">
                            <div class="form-check form-check-flat">
                              <label class="form-check-label">
                                Duplicate a project for new customer
                              <i class="input-helper"></i></label>
                            </div>
                            <i class="remove ti-close"></i>
                          </li>
                          <li>
                            <div class="form-check form-check-flat">
                              <label class="form-check-label">
                                Project meeting with CEO
                              <i class="input-helper"></i></label>
                            </div>
                            <i class="remove ti-close"></i>
                          </li>
                          <li class="">
                            <div class="form-check form-check-flat">
                              <label class="form-check-label">
                                Follow up of team zilla
                              <i class="input-helper"></i></label>
                            </div>
                            <i class="remove ti-close"></i>
                          </li>
                          <li>
                            <div class="form-check form-check-flat">
                              <label class="form-check-label">
                                Level up for Antony
                              <i class="input-helper"></i></label>
                            </div>
                            <i class="remove ti-close"></i>
                          </li> -->
                        </ul>
                      </div>
                    </div>
                  </div>
                
          </div>
        </div>
        </div>
      </div>
    </div>
  </div>

<!-- The Modal -->
<div class="modal fade" id="modalProdCategory">
  <div class="modal-dialog modal-lgx">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Update Category</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-bodyx">
      <form class="cmxform" id="signupForm">
      <div class="card">
          <div class="card-body">
                <fieldset>
                  <div class="form-group">
                    <label for="prodName">Product Name</label>
                    <input id="updateProdName" class="form-control" name="categoryName" type="text">
                    <input type="hidden" id="categoryId" name="categoryId" value="">
                    <small class="text-danger"></small>
                  </div>
                </fieldset>
              
            </div>
          </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" id="btnUpdate">Save</button>
      </div>
    </form>
    </div>
  </div>
</div>

 <!-- toast -->
 <div class="toast" data-delay="3000">
  <div class="toast-header">
    <strong class="mr-auto text-primary">Message</strong>
    <button type="button" class="ml-2 mb-1 close" data-dismiss="toast">&times;</button>
  </div>
  <div class="toast-body">
    ERROR
  </div>
</div>
<!-- endtoast -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- Page level plugins -->


<script src="<?php echo e(URL::to('/public/template/vendors/datatables.net/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(URL::to('/public/template/vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
<!-- <script src="<?php echo e(URL::to('/public/template/js/data-table.js')); ?>"></script> -->

<script src="<?php echo e(URL::to('/public/template/vendors/jquery-validation/jquery.validate.min.js')); ?>"></script>
<!-- <script src="<?php echo e(URL::to('/public/template/vendors/bootstrap-maxlength/bootstrap-maxlength.min.js')); ?>"></script> -->
<!-- <script src="<?php echo e(URL::to('/public/template/js/form-validation.js')); ?>"></script> -->
<script src="<?php echo e(URL::to('/public/index.js')); ?>"></script>
<script>
  
  
  $(function() {
    var todoListItem = $('.todo-list');
    var todoListInput = $('.todo-list-input');
    $('.todo-list-add-btn').on("click", function(event) {
      event.preventDefault();
      var item = $(this).prevAll('.todo-list-input').val();

      var checker = false;
      var labels = $('.form-check-label.product-category').each(function(index) {    
        if($(this).text().trim().toLowerCase() == item.trim().toLowerCase())
        checker =  true;
      });

      if(checker)
      return;

      if (item) {
        let params = JSON.stringify({categoryId: '', categoryName: item});
        request('category', 'POST', params, function(status, data){
          if(status == 200)
          {
            todoListItem.append(`<li><div class='form-check'><a href='#'><label class='form-check-label product-category'>
${item}
<i class="input-helper"></i></label></a></div><i class='remove ti-close' data-id="${data}"></i></li>`);
            todoListInput.val("");
          }
        });        
      }
    }); 



    // update
    // $('.product-category').on("click", function(event) {
    todoListItem.on('click', '.product-category', function() {
      var $text = $(this).text().trim();
      var $id =  $(this).closest('li').find("i.ti-close").attr('data-id');

      $('#updateProdName').val($text);

      $('#categoryId').val($id);
      $("#modalProdCategory").modal('show');
    });
    

    $('#btnUpdate').click(function(e){
        e.preventDefault();
        var Id = $('#categoryId').val();
        var item = $('#updateProdName').val();

        var params = JSON.stringify({categoryId: Id, categoryName: item});
        request('category', 'POST', params, function(status, data){
          if(status == 200)
          {
            location.reload();
          }else{
            $('.text-danger').text(data);
            // $('.toast').toast('show');
          }
        });
    });

    
    // delete
    todoListItem.on('click', '.remove', function() {
      var $this = $(this);
      var params = JSON.stringify({
        categoryId: $(this).data('id'),
      });
      request('delete-category', 'POST', params, function(status, data){
          if(status == 200)
          {
            // $('.toast-body').text('successfully deleted');
            // $('.toast').toast('show');
            $this.parent().remove();
          }else{
            $('.toast-body').text(data);
            $('.toast').toast('show');
          }
      });
    });

    $("#modalProdCategory").on('hide.bs.modal', function(){
      $('.text-danger').text('');
    });
    
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shitmiming/web/saas/resources/views/productcategory.blade.php ENDPATH**/ ?>