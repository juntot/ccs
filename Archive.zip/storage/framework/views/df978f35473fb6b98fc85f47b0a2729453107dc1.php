<!DOCTYPE html>
<html lang="en">
  <head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Skydash Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo e(URL::to('/public/template/vendors/feather/feather.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(URL::to('/public/template/vendors/ti-icons/css/themify-icons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(URL::to('/public/template/vendors/css/vendor.bundle.base.css')); ?>">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo e(URL::to('/public/template/css/vertical-layout-light/style.css')); ?>">
  <!-- endinject -->
  <!-- <link rel="shortcut icon" href="images/favicon.png"> -->
  <link rel="shortcut icon" href="<?php echo e(URL::to('/public/template/images/logo-mini.png')); ?>" />
  <link rel="stylesheet" href="<?php echo e(URL::asset('resources/css/app.css')); ?> ">
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-stretch auth auth-img-bg">
        <div class="row flex-grow">
          <div class="col-lg-6 d-flex align-items-center justify-content-center">
            <div class="auth-form-transparent text-left p-3">
              <div class="brand-logo">
                <img src="<?php echo e(URL::to('/public/template/images/logo.png')); ?>" alt="logo">
              </div>
              <h4>New here?</h4>
              <h6 class="font-weight-light">Join us today! It takes only few steps</h6>
              <form class="pt-3" method="post" action="registration">
                <div class="form-group <?php echo e($errors->has('fullName') ? 'has-danger': ''); ?> ">
                  <label>Full Name</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="ti-user text-primary"></i>
                      </span>
                    </div>
                    <input type="text" value="<?php echo e(old('fullName')); ?>" name="fullName" class="form-control form-control-lg border-left-0" placeholder="Full Name">
                  </div>
                  <?php if($errors->has('fullName')): ?>
                    <small class="text-danger"><?php echo e($errors->first('fullName')); ?></small>
                  <?php endif; ?>
                </div>
                <div class="form-group <?php echo e($errors->has('email') ? 'has-danger': ''); ?> ">
                  <label>Email</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="ti-email text-primary"></i>
                      </span>
                    </div>
                    <input type="text" value="<?php echo e(old('email')); ?>" name="email" class="form-control form-control-lg border-left-0" placeholder="Email">
                  </div>
                  <?php if($errors->has('email')): ?>
                    <small class="text-danger"><?php echo e($errors->first('email')); ?></small>
                  <?php endif; ?>
                </div>
                <div class="form-group <?php echo e($errors->has('state') ? 'has-danger': ''); ?> ">
                  <label>State</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="ti-flag-alt text-primary"></i>
                      </span>
                    </div>
                    <input type="text" value="<?php echo e(old('state')); ?>" name="state" class="form-control form-control-lg border-left-0" placeholder="State">
                  </div>
                  <?php if($errors->has('state')): ?>
                    <small class="text-danger"><?php echo e($errors->first('state')); ?></small>
                  <?php endif; ?>
                </div>
                <div class="form-group <?php echo e($errors->has('suburb') ? 'has-danger': ''); ?> ">
                  <label>Suburb</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="ti-direction text-primary"></i>
                      </span>
                    </div>
                    <input type="text" value="<?php echo e(old('suburb')); ?>" name="suburb" class="form-control form-control-lg border-left-0" placeholder="Suburb">
                  </div>
                  <?php if($errors->has('suburb')): ?>
                    <small class="text-danger"><?php echo e($errors->first('suburb')); ?></small>
                  <?php endif; ?>
                </div>
                <div class="form-group <?php echo e($errors->has('password') ? 'has-danger': ''); ?> ">
                  <label>Password</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="ti-lock text-primary"></i>
                      </span>
                    </div>
                    <input type="password" value="<?php echo e(old('password')); ?>" name="password" class="form-control form-control-lg border-left-0" id="exampleInputPassword" placeholder="Password">                        
                  </div>
                  <?php if($errors->has('password')): ?>
                    <small class="text-danger"><?php echo e($errors->first('password')); ?></small>
                  <?php endif; ?>
                </div>
                <!-- <div class="mb-4">
                  <div class="form-check">
                    <label class="form-check-label text-muted">
                      <input type="checkbox" class="form-check-input">
                      I agree to all Terms &amp; Conditions
                    <i class="input-helper"></i></label>
                  </div>
                </div> -->
                <div class="mt-3">
                  <?php echo e(csrf_field()); ?>

                  <input type="submit" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" value="SIGN UP">
                </div>
                <div class="text-center mt-4 font-weight-light">
                  Already have an account? <a href="<?php echo e(route('login')); ?>" class="text-primary">Login</a>
                </div>
              </form>
            </div>
          </div>
          <div class="col-lg-6 register-half-bg d-flex flex-row hide-on-mobile-background">
            <p class="text-white font-weight-medium text-center flex-grow align-self-end">Copyright © 2021  All rights reserved.</p>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="<?php echo e(URL::to('/public/template/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="<?php echo e(URL::to('/public/template/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(URL::to('/public/template/js/hoverable-collapse.js')); ?>"></script>
  <script src="<?php echo e(URL::to('/public/template/js/template.js')); ?>"></script>
  <script src="<?php echo e(URL::to('/public/template/js/settings.js')); ?>"></script>
  <script src="<?php echo e(URL::to('/public/template/js/todolist.js')); ?>"></script>
  <!-- endinject -->



</body></html><?php /**PATH /Users/shitmiming/web/saas/resources/views/register.blade.php ENDPATH**/ ?>