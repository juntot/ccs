<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
<div class="container-scroller">

    <!-- partial:partials/_navbar.html -->
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- partial -->
    
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
    <!-- Sidebar -->
    <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End of Sidebar -->

        <!-- partial -->
        <div class="main-panel">
            <div class="content-wrapper">
                <?php echo $__env->yieldContent('main'); ?>
            </div>
            <!-- Footer -->
            <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End of Footer -->
        </div>
    </div>
        <!-- End of Content Wrapper -->

</div>
<?php echo $__env->make('layout.footer_asset', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH /Users/shitmiming/web/saas/resources/views/layout/master.blade.php ENDPATH**/ ?>